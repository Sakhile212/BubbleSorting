// 1. generateElement: returns a random integer between 1 and 100 inclusive
const generateElement = () => Math.floor(Math.random() * 100) + 1;

// 2. generateArray: uses generateElement to return an array of five random integers
const generateArray = () => {
  const arr = [];
  for (let i = 0; i < 5; i++) {
    arr.push(generateElement());
  }
  return arr;
};

// 3. generateContainer: creates and returns an empty div element
const generateContainer = () => document.createElement("div");

// 4. fillArrContainer: populates an element with 5 spans showing array integers
const fillArrContainer = (element, arr) => {
  element.innerHTML = "";
  arr.forEach((num) => {
    const span = document.createElement("span");
    span.textContent = num;
    element.appendChild(span);
  });
};

// 5. isOrdered: returns true if first <= second
const isOrdered = (a, b) => a <= b;

// 6. swapElements: swaps element at index and index + 1 if not ordered
const swapElements = (arr, index) => {
  if (!isOrdered(arr[index], arr[index + 1])) {
    const temp = arr[index];
    arr[index] = arr[index + 1];
    arr[index + 1] = temp;
  }
};

// 7. highlightCurrentEls: applies dashed red border to spans at index and index + 1
const highlightCurrentEls = (element, index) => {
  const children = element.children;
  if (children[index] && children[index + 1]) {
    const style = "2px dashed red";
    children[index].style.border = style;
    children[index + 1].style.border = style;
  }
};

// Select DOM elements
const generateBtn = document.getElementById("generate-btn");
const sortBtn = document.getElementById("sort-btn");
const startingArray = document.getElementById("starting-array");
const arrayContainer = document.getElementById("array-container");

let currentArr = [];

// Event listener for Generate Button
generateBtn.addEventListener("click", () => {
  // Clear previous sorting steps (all divs except #starting-array)
  const extraDivs = arrayContainer.querySelectorAll("div:not(#starting-array)");
  extraDivs.forEach((div) => div.remove());
  
  // Clear styles from starting array
  startingArray.innerHTML = "";
  
  // Generate new array and fill container
  currentArr = generateArray();
  fillArrContainer(startingArray, currentArr);
});

// Event listener for Sort Button
sortBtn.addEventListener("click", () => {
  if (currentArr.length === 0) return;

  // Use a copy of the array for sorting
  let arr = [...currentArr];

  // User Story 21: Highlight first two integers in the starting array
  highlightCurrentEls(startingArray, 0);

  // User Story 18 & 19: Implement Bubble Sort with step-by-step visual logic
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr.length - 1; j++) {
      // Modify the array in place
      swapElements(arr, j);

      // Create a container for this step
      const stepContainer = generateContainer();
      fillArrContainer(stepContainer, arr);

      // Highlight the elements to be compared in the NEXT step
      let nextJ = j + 1;
      if (nextJ < arr.length - 1) {
        highlightCurrentEls(stepContainer, nextJ);
      } else if (i < arr.length - 1) {
        // If inner loop ends, highlight start of next pass
        highlightCurrentEls(stepContainer, 0);
      }

      // Append step to the container
      arrayContainer.appendChild(stepContainer);
    }
  }
});
